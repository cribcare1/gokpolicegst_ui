export const LOGIN_CONSTANT = {
 USER_TOKEN: 'userToken',
 USER_ID: 'userId',
 DDO_COUNT: 'ddoCount',
 FORM_16_COUNT: 'form16Count',
 FORM_16A_COUNT: 'form16ACount',
 DDO_USER_NAME: 'ddoUserName',
 DDO_TAN_NUMBER: 'ddoTanNumber',
 EMAIL: 'email',
}
export const FOOTER_TEXT = "© 2025 Dravinlabs Technology Pvt. Ltd. All rights reserved.";
