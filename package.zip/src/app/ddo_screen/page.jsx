"use client";
import DDOButtons from "@/components/admin-screen/admin-components/AddDdoScreen";

export default function page() {
  return (
    <div>
   <DDOButtons/>
    </div>
  )
};