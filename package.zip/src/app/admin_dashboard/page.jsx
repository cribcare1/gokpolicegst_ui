"use client";
import Dashboard from "@/components/admin-screen/admin-dashboard/Layout Component";

export default function page() {
  return (
    <div>
     <Dashboard/>
    </div>
  )
};