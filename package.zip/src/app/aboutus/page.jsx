"use client";
import AboutUs from "@/components/Aboutus";

export default function page() {
  return (
    <div>
     <AboutUs/>
    </div>
  )
};