"use client";
import ContactUsPage from "@/components/Contactus";

export default function page() {
  return (
    <div>
     <ContactUsPage/>
    </div>
  )
};