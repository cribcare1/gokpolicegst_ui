"use client";
import LoginPage from "@/components/ddo-screen/DdoLoginPage";

export default function page() {
  return (
    <div>
   <LoginPage/>
    </div>
  )
};