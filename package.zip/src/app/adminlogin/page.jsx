"use client";
import AdminLogin from "@/components/admin-screen/LoginPage";

export default function page() {
  return (
    <div>
   <AdminLogin/>
    </div>
  )
};