"use client";
import EWingsDashboard from "@/components/ddo-screen/ddo-dashboard/maincomponent";

export default function page() {
  return (
    <div>
   <EWingsDashboard/>
    </div>
  )
};