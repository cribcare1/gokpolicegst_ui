"use client";
import ResetPasswordForm from "@/components/admin-screen/Resetpassword";

export default function page() {
  return (
    <div>
   <ResetPasswordForm/>
    </div>
  )
};